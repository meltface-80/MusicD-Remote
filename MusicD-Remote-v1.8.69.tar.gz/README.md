<div align="center">

<img width="800" alt="MusicD" src="docs/IMG_8974.jpeg" />

</div>

# MusicD Remote (for Roon) - v1.8.67

**📖 Install guide & command builder: [meltface-80.github.io/MusicD-Remote](https://meltface-80.github.io/MusicD-Remote/)**

MusicD Remote is for Roon and is a feature-rich music discovery companion for Roon, helping you rediscover your library through album browsing in a random order, with rich metadata, beautiful wall displays and seamless playback with Roon Server at the heart.

---

## Features

🕒 Listen later — *new in v1.8.67*

Put an album aside to play another time. Roon's own Listen later cannot be reached from an extension, so this is MusicD's own list — kept on the server, the same on every device, and safe across a library rescan.

* **Put albums aside** from an album's ⋯ menu, from a selection of albums on any wall, or with **＋ Listen later** on a Smart Pick
* **A Home row** of everything put aside, newest first — switch it on or off and move it under Settings → Home Screen. Tap its title for the full list
* **Albums you own play** straight from the list. A Smart Pick not in your library yet can be **added to your library** in one tap, or **opened in Qobuz or TIDAL** to hear it first
* **It tidies itself.** An album comes off the list once every track has been played through since you put it aside — on any zone, from any app — or whenever you tap Remove
* **Smart Picks can go here instead of your library.** Settings → Smart Picks → *Send each day's picks to*: **Library** (favourited on Qobuz/TIDAL, as before), **Listen later** (your streaming library is left alone), or **Nowhere** (every pick asks)

⸻

↔️ Previous / next album — *new in v1.8.66*

Step from album to album without leaving the album view.

* **Swipe** the album card sideways, tap the **chevrons** on the cover's edges, or use the **arrow keys**
* Previous and next are the albums either side of the one you opened, on the screen you opened it from — a Home row, the Library wall, an artist or label page — so a swipe walks the list you were looking at
* Close the card and you land on the album you stepped to

⸻

📺 Remote ⇄ wall display, and a screensaver — *new in v1.8.66*

* **Menu → Wall display** turns the remote into the wall display for its zone, and **Remote** on the display (tap the screen to reveal it) brings the remote back exactly as you left it
* **A screensaver timer** — Settings → Wall display → *Switch to the wall display* after 1 to 60 minutes untouched. Set per device and off unless you choose it, so a wall tablet drifts into the display while the phone in your pocket does not
* It never interrupts: it waits while Settings, a sheet or a selection is open
* Shown only while the wall display is switched on

⸻

📡 Live screens — *new in v1.8.65*

Every screen keeps itself up to date — you never have to leave a screen and come back to see a change.

* Home, the Library and Not played walls, the Queue, the album, artist and label pages, Smart Picks and Discover all refresh themselves when something changes: a play, a release date found, a setting changed on another device
* **In place** — your scroll position is kept, nothing flashes "Loading…", and albums that did not change stay exactly where they are
* **Nothing moves under your finger** — a change waits while you are pressing, scrolling or selecting
* The random rows keep their draw: an album you have just played drops out, and nothing else moves

⸻

🧭 Discover — *new in v1.8.50*

New records by the artists you actually listen to. It is the one question the app could not answer: Smart Picks finds acts next to your library that you do not own, and the Pitchfork and streaming screens show what somebody else rates this week — neither can tell you whether anyone you play has put something out.

* **Read from your play history, not your library.** Your library is what you own; your plays are what you came back to. Ranked by how many separate DAYS you played an act, not by play count — forty plays in one night is an evening, eight plays on eight days is a habit
* **Albums only**, from the last two months, and never a record you already have
* **A reissue is not a new record.** A remaster is only refused when the title says so AND the act has an older release under the same name — either signal alone throws away real albums
* **Every row goes somewhere.** In your Roon library it queues; otherwise it opens in your default streaming service, Qobuz by way of the link that opens the Qobuz app
* **Off by default.** Turn it on in Settings → Discover and it looks once a day, at an hour you choose. Nothing touches your Roon Core

⸻

〰️ Waveform — *rebuilt for accuracy in v1.8.24; Qobuz and TIDAL since v1.8.22, reworked in v1.8.51–56*

* The seek bar on Now playing and the wall display's progress strip draw the shape of the track you are listening to — where the quiet intro ends, where the loud middle is
* **Off by default** — turn it on in Settings → Playback → Waveform, and it stays on until you turn it off
* **Each bar is the level of its slice of the track**, measured from both channels at full rate. A bar that is the *loudest moment* in its slice says nothing about a modern master — something touches the ceiling almost everywhere in one — so it drew a brick; this draws the record
* **The shape sits under the playhead**, at every point in the track rather than only halfway through
* Each track is analysed once and stored, so it is instant every time after the first. Coming from a version before v1.8.24 re-analyses them once, as they play, because the numbers come out differently
* The next track in the queue is prepared while the current one plays, so it is already there when the track changes
* **Local files, and Qobuz and TIDAL streams.** Roon streams those services straight to your endpoint and never to an extension, so the track is fetched from the service with your own account, turned into a few thousand loudness values and discarded — no audio is written to disk, and Roon still handles all playback
* Streamed albums are identified from your favourites; a Qobuz album played from search is looked up in the catalogue instead, and an album that cannot be identified confidently is left alone rather than guessed at
* Anything the app cannot read — a track it cannot identify, one your account cannot stream, or one a service delivers in a protected container — simply keeps the plain progress bar
* [How this works, in detail](STREAMING-WAVEFORMS.md) — the identity matching, the duration gate, the signing, and the measurement, with the implementation

⸻

🎵 Album Discovery

* Browse your music library in a fresh and engaging way
* Discover forgotten favourites and hidden gems
* Random album selection with configurable filtering
* Album of the day
* Label of the week
* Play Unheard albums
* Recently unplayed album recommendations
* Continue discovering music automatically with Random Album Radio

Over time with prolonged use the database learns when you last listened to an album and will offer up others instead so you rediscover forgotten albums.

⸻

📚 Rich Library Browsing

Browse your library in multiple ways:

* Your whole library — a Library row on the Home screen opens a full grid that scrolls through every album in your collection
* Albums
* Artists
* Genres
* Record Labels
* Decades
* Tags

Album artwork is cached on the server as your library syncs, so browsing stays fast and puts no extra load on your Roon Core — even with a large collection.

Quickly jump between related artists, albums and labels from anywhere in the application.

⸻

🔍 Powerful Search

Search your music library instantly by:

* Album
* Artist
* Record Label

Optionally extend searches to supported streaming services including:

* Qobuz
* TIDAL

Also browse Qobuz and Tidal directly and add favourites to your Roon library. 

⸻

💿 Detailed Album Pages

Each album includes rich metadata including:

* High resolution artwork
* Track listing
* Release year
* Record label
* Album duration
* Multiple artist support
* Pitchfork review and rating (where available)

Play, queue or browse directly from the album page.

⸻

▶ Playback Integration

Control playback directly from the extension.

Features include:

* Play album immediately
* Queue album
* Queue individual tracks
* Multi-select albums
* Queue multiple albums
* Continue playback automatically when the queue finishes
* Move queue between zones - zone switcher

⸻

📺 Full Screen Wall Display

Turn a TV or tablet into a beautiful now-playing display.

Features include:

* Large album artwork
* Artist photography
* Album reviews
* Artist biographies
* Related albums
* Related artists
* Record label information
* Playback progress
* Automatic information rotation
* Multiple display modes

Ideal for dedicated listening rooms.

Point any browser at `http://<server-ip>:3399/display`.

⸻

🏷 Record Label Explorer

Explore your collection by record label.

Features include:

* Label of the week
* Label artwork
* Discogs integration
* FanArt.tv artwork
* Label merging
* Undo merged labels
* Browse every release from a selected label

⸻

📻 Random Album Radio

Automatically keeps the music flowing.

When the current queue finishes the extension can automatically:

* Select another album
* Avoid recently played albums
* Continue playback indefinitely

Perfect for effortless album listening.

⸻

⭐ Artist Discovery

Learn more about the music you’re listening to.

Includes:

* Artist biographies
* Artist images
* Related artists
* Navigation between artists and albums

⸻

🌐 Online Integrations

Supports information and artwork from:

* Roon
* Qobuz
* TIDAL
* Discogs
* FanArt.tv
* Pitchfork

⸻

📤 Share card — *rebuilt in v1.8.36*

Tap Share on any album or on Now playing and the record gets a card of its own, with somewhere to go underneath it.

* **The card** — album artwork, artist, title, the release year and record label, a short description of the record, and the Pitchfork score with its Best New Music flag where there is one
* **Where to hear it** — Qobuz, TIDAL, Spotify, Apple Music, Amazon Music, Deezer and Bandcamp, each opening a search for the album on that service. Qobuz opens the Qobuz **app** rather than their download store
* **Where to read about it** — Wikipedia, Pitchfork and AllMusic, and the same for the artist if you want them. These link to the actual page when the app has already found it, and to a search when it has not
* **A default service** — hold a service button to set it, or pick one in Settings → Share Card. Remembered per device
* **"If you like this"** — three acts worth hearing next, one record each. Tap one that is in your Roon library and it goes in the queue; tap one that is not and it opens in your default service
* Turn any of the services or review sites on and off in **Settings → Share Card**

⸻

🔄 Automatic Updates

Stay up to date with the latest features.

* Built-in update checker
* GitHub release integration
* One-click updates

⸻

🐳 Docker Support

Designed for simple deployment.

Includes:

* Docker image
* Docker Compose support
* Persistent configuration
* Automatic migration of pairing information
* Simple upgrades

⸻

⚡ Modern Interface

Designed specifically for large music libraries.

* Responsive interface
* Fast navigation
* Mobile friendly
* Desktop friendly
* TV friendly
* Dark/light themes
* Clean album-first design
  
---

## Setting up Discogs and FanArt.tv API keys

Both are free and significantly improve label logo coverage.

### Discogs personal access token

Discogs is used to find label names for albums that iTunes and MusicBrainz miss, and to fetch label logos.

1. Sign in (or register free) at [discogs.com](https://www.discogs.com)
2. Go to **Settings → Developers** → click **Generate new token**
3. Copy the token
4. In the extension, tap the gear icon → paste into **Discogs token** → tap **Save**

### FanArt.tv API key

FanArt.tv provides high-quality label logos for labels that have a MusicBrainz MBID.

1. Register free at [fanart.tv](https://fanart.tv/get-an-api-key/#personal) for a personel API token
2. login or register
3. follow onscreen prompts (or come back here after registering/login and click on above link)
4. Copy the key shown there
5. In the extension, tap the gear icon → paste into **FanArt.tv key** → tap **Save**

---

> **Note on label accuracy** — an album may appear under a label that differs from the one shown in the album view. This could be correct: many albums could be released under multiple labels simultaneously (for example, Daughtry's *Baptized* was released under 19 Recordings, RCA, and Sony Music). The extension shows whichever label your file tags or the scan sources attribute to the album in the case of being a Qobuz or Tidal version.

---

## Install (Docker)

```bash
sudo mkdir -p /opt/musicd-remote
cd /opt/musicd-remote
wget https://github.com/meltface-80/MusicD-Remote/releases/download/v1.8.67/MusicD-Remote-v1.8.67.tar.gz
tar -xzf MusicD-Remote-v1.8.67.tar.gz
docker build -t musicd-remote:1.8.67 .
docker run -d \
  --name musicd-remote \
  --restart unless-stopped \
  --network host \
  -e TZ=Europe/London \
  -v musicd-remote-data:/app/data \
# remove the below line (and this line) if you only use Qobuz/Tidal
  -v /your/path/to/Music:/music:ro \
  musicd-remote:1.8.67
```

> **The `musicd-remote-data` volume holds your Roon pairing, play history, and label cache — never rename it once created.** Point every future `docker run` at the same name and everything carries over; a different name makes Docker silently create a fresh empty volume (new pairing, lost history). **Upgrading from v1.6.31 or earlier?** Your data lives in the old `roon-random-albums-data` volume — move it once with the copy step in [Updating](#updating) below before using this command.

`--network host` is required so the extension can discover your Roon Core on the local network. The `-v musicd-remote-data` flag mounts a named Docker volume so that your Roon pairing, play history, and label cache survive container rebuilds. The `-v .../Music:/music:ro` flag mounts your music directory read-only so the extension can read label tags directly from your files — this is optional but gives the most accurate label data. Adjust the path to match your music library location.

Set `-e TZ=` to your own zone (`Europe/London`, `America/New_York`, …). A container runs on UTC otherwise, which changes which midnight **Album of the day** turns over on and the hour **Smart Picks** switches.

The optional **Discogs** and **FanArt.tv** keys can be supplied at install too, via `RRA_DISCOGS_KEY` and `RRA_FANART_KEY` — put them in a `.env` file next to the command and add `--env-file .env`, rather than inline with `-e`, which would leave them in your shell history and in `docker inspect`. They are first-run seeds only: a key saved in **Settings** always wins, and the [install configurator](https://meltface-80.github.io/MusicD-Remote/#install) writes the `.env` block for you. Qobuz and TIDAL cannot be set this way — both sign in through the service's own page after the container is running, so there is no password for the command to carry.

**More than one music folder?** The scan reads everything under `/music` recursively, so mount each one as its own subdirectory rather than adding a second root — `-v /mnt/nas/Albums:/music/Albums:ro -v /mnt/usb/Vinyl:/music/Vinyl:ro`. A mount at `/music2` would never be looked at. The [install configurator](https://meltface-80.github.io/MusicD-Remote/#install) builds the whole command for you. Note that **Label from folder depth** in Settings counts from `/music`, so with several folders every depth goes up by one.

You should see the extension appear in **Roon → Settings → Extensions** under **MusicD**. Click **Enable**, then browse to `http://<your-server-ip>:3399`.

### Install Docker

If Docker isn't installed yet:

```bash
# DietPi
sudo dietpi-software install 162

# Debian / Ubuntu
curl -sSL https://get.docker.com | sh
```

## Updating

> **Coming from v1.6.31 or earlier (the Roon-Random-Albums days)?** Two one-time steps before the update commands below:
>
> 1. **Stop and remove the old container name**: `sudo docker stop roon-random-albums && sudo docker rm roon-random-albums` (and use the new `/opt/musicd-remote` folder below — the old `/opt/roon-random-albums` folder can be deleted afterwards).
> 2. **Move your data to the new volume name** — your Roon pairing, play history, and label cache live in the old `roon-random-albums-data` volume; copy them once into `musicd-remote-data`:
>
> ```bash
> sudo docker run --rm \
>   -v roon-random-albums-data:/from \
>   -v musicd-remote-data:/to \
>   alpine sh -c "cp -a /from/. /to/"
> ```
>
> Skip step 2 and the new container starts with an empty volume: Roon asks you to authorize again and your history is gone. (Once you've confirmed everything carried over, the old volume can be removed with `sudo docker volume rm roon-random-albums-data`.)


```bash
sudo docker stop musicd-remote
sudo docker rm musicd-remote
sudo rm -f /opt/musicd-remote/MusicD-Remote-vPREVIOUS.tar.gz
cd /opt/musicd-remote
wget https://github.com/meltface-80/MusicD-Remote/releases/download/vNEW/MusicD-Remote-vNEW.tar.gz
tar -xzf MusicD-Remote-vNEW.tar.gz
docker build -t musicd-remote:NEW .
docker run -d \
  --name musicd-remote \
  --restart unless-stopped \
  --network host \
  -e TZ=Europe/London \
  -v musicd-remote-data:/app/data \
# remove the below line (and this line) if you only use Qobuz/Tidal
  -v /your/path/to/Music:/music:ro \
  musicd-remote:NEW
```

## Migrating from a native install

If you're running an older native (non-Docker) install, the app will show a migration banner automatically with copy-ready commands. Or follow these steps.

```bash
# 1. Stop the native service
sudo systemctl stop roon-random-albums
sudo systemctl disable roon-random-albums

# 2. Create the build directory and download the tarball
sudo mkdir -p /opt/musicd-remote
cd /opt/musicd-remote
wget https://github.com/meltface-80/MusicD-Remote/releases/download/v1.8.67/MusicD-Remote-v1.8.67.tar.gz
tar -xzf MusicD-Remote-v1.8.67.tar.gz

# 3. Build and run
docker build -t musicd-remote:1.8.67 .
docker run -d \
  --name musicd-remote \
  --restart unless-stopped \
  --network host \
  -e TZ=Europe/London \
  -v musicd-remote-data:/app/data \
# remove the below line (and this line) if you only use Qobuz/Tidal
  -v /your/path/to/Music:/music:ro \
  musicd-remote:1.8.67
```

Confirm the extension appears in **Roon → Settings → Extensions** before removing the old install.

### Cleaning up the old install

```bash
# Remove the service file
sudo rm /etc/systemd/system/roon-random-albums.service
sudo systemctl daemon-reload

# Remove the old native install directory (find it first if unsure)
find / -name "roon-random-albums" -type d 2>/dev/null
rm -rf /path/to/old/roon-random-albums
```

Your Roon pairing, listening history, and label cache are all safe — they live in the Docker volume (`roon-random-albums-data`).

# MacOS installs as follows

For macOS, the main requirement is to install Docker Desktop first, since Docker is not included with the operating system.

## 1. Install Docker Desktop
• Download Docker Desktop for Mac from:
https://www.docker.com/products/docker-desktop/
(Ensure you’re installing the correct version for Mac or Intel chips)
• Open the downloaded .dmg.
• Drag Docker.app into your Applications folder.
• Launch Docker from Applications.
• Grant any permissions macOS requests.
• Wait until Docker Desktop reports Engine running (the whale icon in the menu bar will stop animating).
• Verify Docker is installed:

```
docker --version
docker compose version
```

You should see version information for both commands.

## 2. Download and build the extension
Open Terminal and run:

```
mkdir -p ~/musicd-remote
cd ~/musicd-remote
curl -L -o MusicD-Remote-v1.8.67.tar.gz \
https://github.com/meltface-80/MusicD-Remote/releases/download/v1.8.67/MusicD-Remote-v1.8.67.tar.gz
tar -xzf MusicD-Remote-v1.8.67.tar.gz
docker build -t musicd-remote:1.8.67 .
```

## 3. Run the container
If you use local music replace /Users/yourusername/Music with the folder containing your music library. Note: add your Roon server IP. 

```
docker run -d \
  --name musicd-remote \
  --restart unless-stopped \
  -p 3399:3399 \
  -e ROON_CORE_IP=<IP_OF_YOUR_ROON_CORE> \
  -e TZ=Europe/London \
  -v musicd-remote-data:/app/data \
  -v /Users/yourusername/Music:/music:ro \
  musicd-remote:1.8.67
```

Or if you only use Qobuz or TIDAL

```
docker run -d \
  --name musicd-remote \
  --restart unless-stopped \
  -p 3399:3399 \
  -e ROON_CORE_IP=<IP_OF_YOUR_ROON_CORE> \
  -e TZ=Europe/London \
  -v musicd-remote-data:/app/data \
  musicd-remote:1.8.67
```

## 4. Open the extension
In your browser, go to: (don’t forget to use your Roon server IP address)

`http://<your.server.IP>:3399`

Please let me know if you run into any trouble.

## Configuration

| Env var      | Default   | What it does |
|--------------|-----------|--------------|
| `PORT`       | `3399`    | HTTP port the UI listens on |
| `RRA_DEBUG`  | on in Docker | Verbose logging (timestamps, Roon API call traces with durations, API request traces). **On by default inside Docker** — set to `0` for quiet logs, or `1` to force it on outside Docker |
| `MUSIC_DIR`  | `/music`  | Path where your music library is mounted inside the container. The scan reads everything **under** it, so several libraries can be mounted as subdirectories — `/music/Albums`, `/music/Vinyl` — rather than as a second root |
| `TZ`         | `Etc/UTC` | The container's local time. Sets which midnight **Album of the day** turns over on and the hour **Smart Picks** switches. The 6- and 12-month "not played" windows count elapsed time, so they read the same in any zone |
| `RRA_DISCOGS_KEY` | *(unset)* | Seeds the Discogs token on a fresh data volume, so label logos work from the very first scan instead of waiting for a visit to Settings. A token saved in **Settings** always wins over it, and an env-seeded key is **not** written to disk — unset the variable and the key is gone |
| `RRA_FANART_KEY` | *(unset)* | Seeds the FanArt.tv key the same way |
| `ROON_CORE_IP` | *(discover)* | Roon Core address, for setups where multicast discovery can't reach it (macOS / Docker Desktop). When set, the extension connects to the Core directly instead of discovering it |
| `ROON_CORE_PORT` | `9330` | Roon Core API port used with `ROON_CORE_IP` — only change it if your Core runs its API on a non-standard port |

### Logs

Everything the extension prints is also written to the data volume, Roon-style:
`data/logs/MusicD-Remote_log.txt` is the current file; at ~8 MB it rotates to
`MusicD-Remote_log.01.txt` (newest) through `.10.txt` (oldest, then dropped) — about
88 MB worst case, surviving container rebuilds and updates. Grab them for a bug report with:

```bash
docker run --rm -v musicd-remote-data:/data alpine tar -czf - -C /data logs > musicd-logs.tar.gz
```

`docker logs musicd-remote` shows the same lines live.

Pass extra env vars with `-e` in the `docker run` command:

```bash
docker run -d ... -e RRA_DEBUG=1 musicd-remote:1.8.67
```

### Album metadata sources

No keys required for basic operation. The extension pulls in external metadata from:

- **Release year** — MusicBrainz (free, public API)
- **Label name** — file tags → Bandcamp (for Bandcamp purchases) → iTunes → TheAudioDB → MusicBrainz → Discogs (each free; Discogs needs a personal access token for best results)
- **Label logo** — FanArt.tv (requires free API key) → Discogs (requires personal access token)
- **Editorial review** — Qobuz public album page, falling back to Wikipedia
- **Artist bio** — Wikipedia

## Troubleshooting

- **"Waiting for Roon Core" never goes away**
  → Roon → Settings → Extensions → click **Enable** on *Random Albums*.
- **Extension shows "self" instead of "MusicD"**
  → Update to v1.5.31 or later.
- **Play Now does nothing**
  → Confirm a real zone is selected in the Settings dropdown.
- **"No zones available"**
  → No active outputs visible to Roon yet. Wake a device or pick one in Roon's own remote first.
- **Labels page shows no logos**
  → Add your Discogs token and FanArt.tv key in Settings (gear icon), then tap Force rescan.
- **Discogs token save doesn't stick**
  → Ensure the field shows your token in plain text before tapping Save. If it still fails, check `docker logs musicd-remote` for a confirmation line.

## File layout

```
/opt/musicd-remote/
├── Dockerfile
├── .dockerignore
├── package.json
├── LICENSE                 # MIT
├── launcher.js             # supervises index.js; applies updates on restart
├── index.js                # Roon API + Express server
├── lib/
│   ├── updater.js          # GitHub release check + download/apply
│   └── radio.js            # random album radio decision logic
├── public/
│   ├── index.html
│   ├── style.css
│   ├── app.js
│   └── sharecard.js
└── README.md
```

## License

Roon Random Albums is released under the **MIT License**. The full text is in the [`LICENSE`](./LICENSE) file. In short: do what you like with it, just keep the copyright and license notice. It comes with no warranty.

Copyright (c) 2026 Lewis Menzies (Music Duck / MusicD).
